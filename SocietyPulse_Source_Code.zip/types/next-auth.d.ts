import "next-auth";
import "next-auth/jwt";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "RESIDENT" | "ADMIN";
      societyId: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
    };
  }

  interface User {
    id: string;
    role: "RESIDENT" | "ADMIN";
    societyId: string;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    role: "RESIDENT" | "ADMIN";
    societyId: string;
  }
}